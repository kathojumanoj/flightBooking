import React, { useState } from 'react';
import './Signup.css';
import axios from 'axios'; 
import { useNavigate } from 'react-router-dom';

const Signup = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [phno, setPhno] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const navigate=useNavigate();
  const isLoggedIn = sessionStorage.getItem("isLoggedIn");
    const userEmail = sessionStorage.getItem("email");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3001/signup', {
        username,
        email,
        phno,
        password,
      });

      setMessage(response.data.message);
    } catch (error) {
      setMessage(error.response?.data?.message || 'Error occurred.');
    }
  };

  if(isLoggedIn)
  {
    navigate("/home");
  }
  else
  {
  return (
    <div className="signup-container">
      <div className="signup-form">
        <h1>Create an Account</h1>
        <p>Join us and explore the best food delivery experience.</p>
        <form onSubmit={handleSubmit}>
          <span>Name</span>
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            required
            onChange={(e) => setUsername(e.target.value)}
          />
          <span>Email</span>
          <input
            type="email"
            name="email"
            placeholder="Example@email.com"
            required
            onChange={(e) => setEmail(e.target.value)}
          />
          <span>Ph no</span>
          <input
            type="text"
            name="phno"
            placeholder="+91"
            required
            onChange={(e) => setPhno(e.target.value)}
          />
          <span>Password</span>
          <input
            type="password"
            name="password"
            placeholder="At least 8 characters"
            required
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit" >Sign Up</button>
        </form>
        <p>
          Already have an account? <a href="/login">Sign In</a>
        </p>
      </div>
      {message && <p>{message}</p>}
    </div>
  );
}
};

export default Signup;
