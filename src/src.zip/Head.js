import React from "react";
import "./Head.css";
import { useNavigate, useLocation,NavLink } from 'react-router-dom';
import Signup from "./Signup";

export default function Head() {
  const location = useLocation();
  const navigate = useNavigate();
  
  const {name}= location.state || {}; 
  const isLoggedIn = sessionStorage.getItem("isLoggedIn");
    const userEmail = sessionStorage.getItem("email");
    const username = sessionStorage.getItem("username");

    const handleLogout = () => {
      // Clear session storage on logout
      sessionStorage.clear();
      navigate("/login");
    };
    
    <>
      <NavLink to="/login">Login</NavLink>
      <NavLink to="/">Register</NavLink>
    </>
    if(isLoggedIn)
    {

      
      return (
        
        <>
        <h1 style={{textAlign:"center"}}>Welcome {username}!</h1>
        <div className="home-container">
  <NavLink to="/">Register</NavLink>
      <NavLink to="/login">Login</NavLink>
      <div style={{
        maxWidth:"600px",
        padding:"100px",
        margin:"auto",
        fontSize:"25px"
      }}> 
          <h2>Welcome to AirConnects...!  </h2>
     
          <span>
          Welcome to AirConnects, your trusted partner in seamless air
          travel experiences! Whether you're flying for business or leisure,
            our commitment is to provide you with unparalleled service, comfort,
            and efficiency.
            </span>
      <button onClick={handleLogout}>logout</button>
    
        </div>
        </div>
    </>
  );
}
else{
  navigate("/");
}

}

